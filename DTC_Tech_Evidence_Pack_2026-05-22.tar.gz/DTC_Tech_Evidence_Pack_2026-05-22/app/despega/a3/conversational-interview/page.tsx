'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ArrowLeft } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useAuthRedirect } from '@/hooks/use-auth-redirect'
import { ConversationalInterviewSimulator } from '@/components/conversational-interview-simulator'
import { TrainingResultsCard } from '@/components/training-results-card'

export default function ConversationalInterviewPage() {
  const router = useRouter()
  const { user, loading } = useAuthRedirect()
  const [selectedRole, setSelectedRole] = useState<string | null>(null)
  const [selectedIndustry, setSelectedIndustry] = useState<string | null>(null)
  const [selectedLevel, setSelectedLevel] = useState<'basico' | 'intermedio' | 'avanzado' | null>(null)
  const [showingFarewell, setShowingFarewell] = useState(false)
  const [showingResults, setShowingResults] = useState(false)
  const [score, setScore] = useState(0)

  const roles = ['Software Engineer', 'Product Manager', 'Data Scientist', 'Operations Manager', 'Marketing Lead']
  const industries = ['Tech', 'Finance', 'Healthcare', 'E-commerce', 'Consulting']
  const levels = [
    { id: 'basico', label: 'Básico - 3 preguntas', desc: 'Preguntas fundacionales' },
    { id: 'intermedio', label: 'Intermedio - 3 preguntas', desc: 'Preguntas situacionales' },
    { id: 'avanzado', label: 'Avanzado - 3 preguntas', desc: 'Preguntas estratégicas' }
  ]

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-400"></div>
      </div>
    )
  }

  if (!user) return null

  if (showingResults) {
    return (
      <TrainingResultsCard
        result={{
          score: score,
          questionsCompleted: 3,
          totalQuestions: 3,
          timeSpent: 900,
          level: selectedLevel || 'intermedio',
          trainingType: 'Entrevista Conversacional'
        }}
        onContinue={() => {
          setSelectedLevel(null)
          setSelectedRole(null)
          setSelectedIndustry(null)
          setShowingResults(false)
          setShowingFarewell(false)
          router.push('/despega/a3')
        }}
      />
    )
  }

  if (showingFarewell) {
    return (
      <main className="min-h-screen bg-background flex items-center justify-center px-4">
        <div className="max-w-md w-full space-y-6">
          <Card className="rounded-[2px] border-training/40 overflow-hidden">
            <div className="relative aspect-[3/4] w-full bg-black">
              <video
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Sofia02ciao-JJXsroDrldJQrOQgg1lHrJzODwH1Uf.mov"
                autoPlay
                playsInline
                crossOrigin="anonymous"
                className="w-full h-full object-contain"
                onEnded={() => setShowingResults(true)}
                style={{ width: '100%', height: '100%' }}
              />
            </div>
          </Card>

          <Card className="rounded-[2px] border-training/30 bg-training/5">
            <CardContent className="pt-6">
              <p className="text-white/85 text-center">
                Sofia se está despidiendo...
              </p>
            </CardContent>
          </Card>
        </div>
      </main>
    )
  }

  if (showingFarewell) {
    return (
      <main className="min-h-screen bg-background flex items-center justify-center px-4">
        <div className="max-w-md w-full space-y-6">
          <Card className="rounded-[2px] border-training/40 overflow-hidden">
            <div className="relative aspect-[3/4] w-full bg-black">
              <video
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Sofia02ciao-JJXsroDrldJQrOQgg1lHrJzODwH1Uf.mov"
                autoPlay
                playsInline
                crossOrigin="anonymous"
                className="w-full h-full object-contain"
                onEnded={() => {
                  setSelectedLevel(null)
                  setSelectedRole(null)
                  setSelectedIndustry(null)
                  setShowingFarewell(false)
                  router.push('/despega/a3')
                }}
                style={{ width: '100%', height: '100%' }}
              />
            </div>
          </Card>

          <Card className="rounded-[2px] border-training/30 bg-training/5">
            <CardContent className="pt-6">
              <p className="text-white/85 text-center">
                Sofia se está despidiendo...
              </p>
            </CardContent>
          </Card>
        </div>
      </main>
    )
  }

  if (!user) return null

  // Si está listo para la entrevista
  if (selectedRole && selectedIndustry && selectedLevel) {
    return (
      <main className="min-h-screen bg-black">
        <div className="flex flex-col min-h-screen">
          <div className="flex-shrink-0 border-b border-muted/80 bg-background">
            <Link href="/despega/a3">
              <Button variant="ghost" className="text-purple-400 hover:text-purple-400/80">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Volver al Dashboard
              </Button>
            </Link>
          </div>
          <div className="flex-1 overflow-y-auto">
            <ConversationalInterviewSimulator
              level={selectedLevel}
              onComplete={(result: any) => {
                setScore(result.score || 85)
                setShowingFarewell(true)
              }}
            />
          </div>
        </div>
      </main>
    )
  }

  // Seleccionar configuración
  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <Link href="/despega/a3">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver al Dashboard
          </Button>
        </Link>

        <div className="space-y-8">
          <div>
            <h1 className="text-4xl font-bold mb-2">Simulación de Entrevista Conversacional</h1>
            <p className="text-muted-foreground dark:text-muted-foreground">
              Personaliza tu entrevista y practica con IA como entrevistador
            </p>
          </div>

          {/* Rol */}
          <div className="bg-white dark:bg-card rounded-[28px] p-6 border border-muted/20 dark:border-card">
            <h2 className="text-lg font-semibold mb-4">1. Selecciona el Puesto</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {roles.map(role => (
                <button
                  key={role}
                  onClick={() => setSelectedRole(role)}
                  className={`p-3 rounded-[28px] border-2 transition ${
                    selectedRole === role
                      ? 'border-training bg-training/5 dark:bg-training/20'
                      : 'border-muted/20 dark:border-card hover:border-training/40'
                  }`}
                >
                  {role}
                </button>
              ))}
            </div>
          </div>

          {/* Industria */}
          {selectedRole && (
            <div className="bg-white dark:bg-card rounded-[28px] p-6 border border-muted/20 dark:border-card">
              <h2 className="text-lg font-semibold mb-4">2. Selecciona la Industria</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {industries.map(industry => (
                  <button
                    key={industry}
                    onClick={() => setSelectedIndustry(industry)}
                    className={`p-3 rounded-[28px] border-2 transition ${
                      selectedIndustry === industry
                        ? 'border-training bg-training/5 dark:bg-training/20'
                        : 'border-muted/20 dark:border-card hover:border-training/40'
                    }`}
                  >
                    {industry}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Nivel */}
          {selectedRole && selectedIndustry && (
            <div className="bg-white dark:bg-card rounded-[28px] p-6 border border-muted/20 dark:border-card">
              <h2 className="text-lg font-semibold mb-4">3. Selecciona el Nivel de Dificultad</h2>
              <div className="space-y-3">
                {levels.map(level => (
                  <button
                    key={level.id}
                    onClick={() => setSelectedLevel(level.id as any)}
                    className={`w-full p-4 rounded-[28px] border-2 transition text-left ${
                      selectedLevel === level.id
                        ? 'border-training bg-training/5 dark:bg-training/20'
                        : 'border-muted/20 dark:border-card hover:border-training/40'
                    }`}
                  >
                    <div className="font-semibold">{level.label}</div>
                    <div className="text-sm text-muted-foreground dark:text-muted-foreground">{level.desc}</div>
                  </button>
                ))}
              </div>

              <Button
                className="w-full mt-6 py-6 bg-training hover:bg-training/90 text-white text-lg"
                onClick={() => {}}
              >
                Comenzar Entrevista
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
