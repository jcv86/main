import { createClient, createAdminClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'

/**
 * API endpoint to save A1 Cerebral test results to Supabase
 * Expects user_id, responses, questions, and disc_profile in request body
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as {
      user_id: string
      responses: unknown
      questions: unknown
      disc_profile: Record<string, number>
    }
    const { responses, questions, disc_profile, user_id } = body

    const supabase = await createClient()
    const supabaseAdmin = createAdminClient()
    
    if (!user_id) {
      console.error('[v0] No user_id provided')
      return NextResponse.json({ error: 'User ID required' }, { status: 400 })
    }

    // Fetch auth user details
    const { data: authUser, error: authError } = await supabaseAdmin.auth.admin.getUserById(user_id)
    const userEmail = authUser?.user?.email || ''
    console.log('[v0] User email from auth:', userEmail)
    
    // Ensure user exists in public users table (create if missing)
    // Use admin client to bypass RLS - this handles OAuth users who don't have a public.users record
    try {
      const { error: userCheckError } = await supabaseAdmin
        .from('users')
        .upsert(
          {
            id: user_id,
            email: userEmail,
            full_name: authUser?.user?.user_metadata?.full_name || authUser?.user?.user_metadata?.name || '',
            avatar_url: authUser?.user?.user_metadata?.avatar_url || authUser?.user?.user_metadata?.picture || '',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          },
          { onConflict: 'id', ignoreDuplicates: true }
        )
      
      if (userCheckError) {
        console.error('[v0] Error ensuring user in public table:', userCheckError)
        // Don't fail - user creation is secondary to test data persistence
        console.log('[v0] Continuing with test save despite user creation error')
      } else {
        console.log('[v0] User record ensured in public users table')
      }
    } catch (err) {
      console.error('[v0] Exception during user creation:', err)
      // Continue - user record is optional for test data
    }
    
    // Calculate dominant and secondary patterns from scores
    const sortedDimensions = Object.entries(disc_profile).sort((a, b) => b[1] - a[1])
    const dominant_pattern = String(sortedDimensions[0]?.[0] || 'D')
    const secondary_pattern = String(sortedDimensions[1]?.[0] || 'I')
    
    console.log('[v0] Patterns - Dominant:', dominant_pattern, 'Secondary:', secondary_pattern)
    
    // Prepare insert data
    const insertData = {
      user_id,
      responses,
      questions,
      disc_profile,
      dominant_pattern,
      secondary_pattern,
      completed_at: new Date().toISOString()
    }
    
    console.log('[v0] Inserting into a1_cerebral_assessment')
    
    // Insert with explicit error handling
    const { data, error } = await supabase
      .from('a1_cerebral_assessment')
      .insert([insertData])
      .select()
    
    if (error) {
      console.error('[v0] Supabase insert error:', {
        message: error.message,
        code: error.code,
        details: error.details,
        hint: error.hint
      })
      return NextResponse.json(
        { error: error.message || 'Failed to save test results' },
        { status: 400 }
      )
    }
    
    console.log('[v0] [CANONICAL] Successfully saved A1 Cerebral assessment')
    
    // Update despega_user_profiles to mark A1 test as completed with CANONICAL FLAGS
    console.log('[v0] [CANONICAL] Updating despega_user_profiles for user:', user_id)
    
    const { error: profileError } = await supabaseAdmin
      .from('despega_user_profiles')
      .upsert({
        user_id,
        a1_cerebral_completed: true,
        a1_cerebral_completed_at: new Date().toISOString(),
        a1_report_seen: true,
        a1_report_seen_at: new Date().toISOString()
      }, { onConflict: 'user_id' })
    
    if (profileError) {
      console.error('[v0] [CANONICAL] Error updating user profile:', profileError)
      return NextResponse.json(
        { error: 'Test saved but failed to update profile: ' + profileError.message },
        { status: 400 }
      )
    }
    
    console.log('[v0] [CANONICAL] User profile updated with A1 completion flags')
    
    return NextResponse.json({
      success: true,
      data: data[0]
    })
    
  } catch (err) {
    console.error('[v0] Unexpected error in A1 Cerebral save:', err)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
